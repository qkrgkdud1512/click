package boarder.bean;

public class PageDto {

	
}

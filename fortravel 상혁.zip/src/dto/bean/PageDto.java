package dto.bean;

public class PageDto {

	
}


package border.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import border.bean.Dto;

public class Dao_getscreen {
	Connection conn = null;
	Statement stmt = null;

	public Dao_getscreen() {// db연결할때 무조건 두개 사용
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (Exception e) {

		}
	}

	public void Driver() { // 드라이버연결해주는 함수,db 열어줌
		try {
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/pro?useSSL=false&useUnicode=true&characterEncoding=utf8", "root", "gkdud0477");
		} catch (Exception e) {

		}
	}
	
	public  ArrayList<Dto> list(String number) {// 바깥에 있는 자료쓰고싶어서 매개변수를 선언해줌
		ArrayList<Dto> borderlist = new ArrayList<Dto>();
		Driver();
		int num;
		num=Integer.parseInt(number);
		try {
			stmt = conn.createStatement();
			String command = "select * from border where number="+num+";";
			ResultSet rs = stmt.executeQuery(command);	
			
			while(rs.next()){
				Dto dto = new Dto();
				dto.setNumber(rs.getInt("number"));
				dto.setCategory(rs.getString("category"));
				dto.setTitle(rs.getString("title"));
				dto.setWritter(rs.getString("writter"));
				dto.setDate(rs.getDate("date"));
				dto.setHits(rs.getInt("hits"));
				dto.setContext(rs.getString("context"));
				borderlist.add(dto);
			}
			
		

			
			stmt.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		closed();
return borderlist;
	}

	public void closed() {// db닫아주는 함수
		try {
			stmt.close();
		} catch (Exception ignored) {
		}
		try {
			conn.close();
		} catch (Exception ignored) {
		}
	}

}

package border.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import border.bean.Dto;

public class Dao {
	
	Connection conn=null; 
	Statement stmt=null;	
	
public Dao() {//db연결할때 무조건 두개 사용
	try{
		Class.forName("com.mysql.jdbc.Driver");
	}catch(Exception e) {
		
	}
}
public void Driver() { //드라이버연결해주는 함수,db 열어줌
	try {
		 conn= DriverManager.getConnection("jdbc:mysql://localhost:3306/pro","root","gkdud0477");
	}catch(Exception e) {
		
	}
}
public void closed() {//db닫아주는 함수
	try{
		stmt.close();
	} catch(Exception ignored) {
	}
	try{
		conn.close();
	}catch (Exception ignored) {
	} 
	}
	
public ArrayList<Dto> list() {
	ResultSet rs;
	ArrayList<Dto> borderlist = new ArrayList<Dto>();
	
	try{
		Driver();
	stmt = conn.createStatement();
	String command = "select * from border;";
	rs = stmt.executeQuery(command);
	
	while(rs.next()){
		Dto dto=new Dto();
		dto.setNumber(rs.getInt("number"));
		dto.setCategory(rs.getString("category"));
		dto.setTitle(rs.getString("title"));
		dto.setWritter(rs.getString("writter"));
		dto.setDate(rs.getDate("date"));
		dto.setHits(rs.getInt("hits"));
		borderlist.add(dto);
	}
System.out.println(borderlist.size());
	}catch (Exception ignored) {
	} closed();
	return borderlist;
	}
	
}



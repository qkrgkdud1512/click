package border.dao;

import java.sql.Connection;
import java.sql.DriverManager;

import java.sql.Statement;

public class Dao_insert {
	Connection conn = null;
	Statement stmt = null;

	public Dao_insert() {// db연결할때 무조건 두개 사용
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (Exception e) {

		}
	}

	public void Driver() { // 드라이버연결해주는 함수,db 열어줌
		try {
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/pro", "root", "gkdud0477");
		} catch (Exception e) {

		}
	}

	public void list(String category, String title, String name) {// 바깥에 있는 자료쓰고싶어서 매개변수를 선언해줌
		Driver();
		try {
			stmt = conn.createStatement();
			String command = String.format("insert into border(category,title,writter) values('%s','%s','%s');",
					category, title, name);
			stmt.executeUpdate(command);
			stmt.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		closed();

	}

	public void closed() {// db닫아주는 함수
		try {
			stmt.close();
		} catch (Exception ignored) {
		}
		try {
			conn.close();
		} catch (Exception ignored) {
		}
	}

}
